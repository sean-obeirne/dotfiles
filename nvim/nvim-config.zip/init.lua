require('config.vim-config')

require("config.lazy")

require('config.keybind-config')

require('config.nvim-config')

