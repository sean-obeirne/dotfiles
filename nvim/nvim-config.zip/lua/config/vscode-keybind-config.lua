----------------
--- KEYBINDS ---
----------------

local opts = {noremap = true, silent = true} -- non-mapped only
local all = {'n', 'i', 'v', 'c', 'o',}

-- Remap hjkl to jkl;
vim.keymap.set('n', 'j', 'h')
vim.keymap.set('n', 'k', 'j')
vim.keymap.set('n', 'l', 'k')
vim.keymap.set('n', ';', 'l')

-- Disable q: command-line window, also pgup/down and f1 help
vim.keymap.set(all, '<F1>', '<Nop>', opts)
vim.keymap.set(all, '<PageUp>', '<Nop>', opts)
vim.keymap.set(all, '<PageDown>', '<Nop>', opts)
vim.keymap.set('n', 'q:', '<Nop>', opts)

-- Save file with Ctrl-s
vim.keymap.set({'n', 'i', 'v'}, '<C-s>', '<Esc>:w<CR>', opts)

-- Copy selected text to clipboard
vim.opt.clipboard = 'unnamedplus'

-- Copy whole file
vim.keymap.set({'n', 'i', 'v'}, '<C-a>', function()
    local saved_cursor = vim.api.nvim_win_get_cursor(0)
    vim.cmd('normal! ggyG')
    vim.api.nvim_win_set_cursor(0, saved_cursor)
end, opts)

-- Toggle window transparency
vim.keymap.set({'n', 'i', 'v'}, '<C-t>', ':TransparentToggle<CR>', opts)

-- Clear search highlights with leader-n
vim.keymap.set('n', '<leader>n', ':noh<CR>', opts)

-- Show (print()) messages
vim.keymap.set('n', '<leader>m', ':messages<CR>', opts)

-- Open Mason
vim.keymap.set('n', '<leader>lm', ':Mason<CR>', opts)

-- Manipulate active LSP
vim.keymap.set('n', '<leader>lr', ':LspRestart<CR>:LspRestart<CR>', opts)
vim.keymap.set('n', '<leader>ls', ':LspStart<CR>:LspStart<CR>', opts)
vim.keymap.set('n', '<leader>lt', ':LspStop<CR>:LspStop<CR>', opts)
vim.keymap.set('n', '<leader>ld', ':lua ShowDiagnosticUnderCursor()<CR>', opts)

-- Swap 'f' and 't' functionalities for deletion
vim.keymap.set('n', 'df', 'dt', opts)
vim.keymap.set('n', 'yf', 'yt', opts)
vim.keymap.set('n', 'cf', 'ct', opts)

-- And vice versa
vim.keymap.set('n', 'dt', 'df', opts)
vim.keymap.set('n', 'yt', 'yf', opts)
vim.keymap.set('n', 'ct', 'cf', opts)

-- Easier way to get to the end and beginning of a line
vim.keymap.set('n', 'E', '$', opts)
vim.keymap.set('n', 'B', '<Home>', opts)


-- In-line comment
vim.keymap.set({'n', 'v'}, '<leader>/', ':normal gcc<CR>', opts)

-- Set custom characters for split borders
vim.opt.fillchars = {
  vert =      '│', -- Vertical line
  horiz =     '─', -- Horizontal line
  horizup =   '┴', -- Horizontal line going up
  horizdown = '┬', -- Horizontal line going down
  vertleft =  '┤', -- Vertical line going left
  vertright = '├', -- Vertical line going right
  verthoriz = '┼'  -- Vertical and horizontal intersection
}
